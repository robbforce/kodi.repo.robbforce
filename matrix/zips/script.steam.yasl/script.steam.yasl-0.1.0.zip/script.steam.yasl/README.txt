(Y)et (A)nother Steam Launcher - An add-on for Kodi to launch the Steam desktop or Big Picture.

https://github.com/robbforce/script.ya.steam.launcher
https://steam.link/
http://kodi.tv/


2023-11-17:
Initial build.
