Playnite Launcher - An add-on for Kodi to launch the Playnite video game manager.

https://github.com/robbforce/script.playnite.launcher
https://playnite.link/
http://kodi.tv/


2021-05-01:
Uplifted addon files to Kodi v19.
Uplifted python script to python 3.
Refactored some minor logic in main.py, to simplify pathing.
Refactored the global variables of main.py using a method that allows the script in memory to become a collection
and remapped throughout.
Renamed functions and variables in main.py.
Replaced os.path.joins with pathlib and xbmcvfs equivalents.
Replaced string handling with modern f-string equivalents available in python 3.6.
